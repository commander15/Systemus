#include "permission.h"

#include <SystemusCore/private/authorizationdata_p.h>

namespace Systemus {

Permission &Permission::operator=(const Permission &other)
{
    AuthorizationData::operator=(other);
    return *this;
}

}
