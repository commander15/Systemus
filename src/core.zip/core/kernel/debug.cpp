#include "debug_p.h"

Q_LOGGING_CATEGORY(systemusSql, "systemus.sql" , QtMsgType::QtWarningMsg);
