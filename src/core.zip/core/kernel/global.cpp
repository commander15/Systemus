#include "global.h"

#include <SystemusCore/user.h>
#include <SystemusCore/private/user_p.h>

#include <SystemusCore/role.h>
#include <SystemusCore/group.h>
#include <SystemusCore/privilege.h>
#include <SystemusCore/permission.h>

#include <QtCore/qjsonobject.h>


void Systemus::init(int argc, char *argv[])
{
    _s_register_internal_types();
}

void _s_transfer_privilege(const Systemus::Data *from, Systemus::Data *to, int type);
void _s_generate_json_privilege(const Systemus::Data &data, QJsonObject *object);

void _s_register_internal_types()
{
    static bool registered(false);
    if (!registered)
        registered = true;
    else
        return;

    sRegisterType<Systemus::User>();
    sRegisterType<Systemus::UserProfile>();
    sRegisterType<Systemus::Role>();
    sRegisterType<Systemus::Group>();
    sRegisterType<Systemus::Privilege>();
    sRegisterType<Systemus::Permission>();
}

void _s_transfer_privilege(const Systemus::Data *from, Systemus::Data *to, int type)
{
    if (type == 0) {
        auto *data = static_cast<const Systemus::PrivilegedDataPrivate *>(from->internalData());
        to->setProperty("privileges", QVariant::fromValue(data->privileges));
        to->setProperty("permissions", QVariant::fromValue(data->permissions));
    } else if (type == 1) {
        auto *data = static_cast<Systemus::PrivilegedDataPrivate *>(to->internalData());
        data->privileges = from->property("privileges").value<Systemus::ManyToManyRelation<Systemus::Privilege>>();
        data->permissions = from->property("permissions").value<Systemus::ManyToManyRelation<Systemus::Permission>>();
    }
}

void _s_generate_json_privilege(const Systemus::Data &d, QJsonObject *object)
{
    const Systemus::DataPrivate *data = static_cast<const Systemus::DataPrivate *>(d.internalData());

    if (data->dataType() >= Systemus::DataPrivate::PrivilegeDataType || data->dataType() <= Systemus::DataPrivate::GroupDataType) {
        auto data = static_cast<const Systemus::PrivilegedDataPrivate *>(d.internalData());
    }
}
